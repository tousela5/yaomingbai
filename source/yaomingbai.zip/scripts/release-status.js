const fs = require('fs');
const path = require('path');

const marker = path.join(__dirname, '..', 'deploy', 'public-url.txt');
if (!fs.existsSync(marker)) {
  console.log('本地静态站点已准备好；尚未配置永久公网访问地址。');
  process.exitCode = 1;
} else {
  const url = fs.readFileSync(marker, 'utf8').trim();
  console.log(url ? `已配置公网地址：${url}` : '公网地址文件为空。');
}
